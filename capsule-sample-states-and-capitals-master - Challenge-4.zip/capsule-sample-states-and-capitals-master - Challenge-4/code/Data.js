module.exports = {
  STATES_DATA: [{
      state: "alabama",
      capital: "Montgomery",
      imgURL: "alabama.png",
      population:1098756
    },
    {
      state: "alaska",
      capital: "Juneau",
      imgURL: "alaska.png",
      population:1098234
    },
    {
      capital: "Phoenix",
      state: "arizona",
      imgURL: "arizona.png",
      population:12345678
    },
    {
      state: "arkansas",
      capital: "Little Rock",
      imgURL: "arkansas.png",
      population:90000
    },
    {
      state: "california",
      capital: "Sacramento",
      imgURL: "california.png",
      population:768798
    },
    {
      state: "colorado",
      capital: "Denver",
      imgURL: "colorado.png",
      population:87656
    },
    {
      state: "connecticut",
      capital: "Hartford",
      imgURL: "connecticut.png",
      population:90000
    },
    {
      state: "delaware",
      capital: "Dover",
      imgURL: "delaware.png",
      population:765468,
    },
    {
      state: "florida",
      capital: "Tallahassee",
      imgURL: "florida.png",
      population:90000
    },
    {
      state: "georgia",
      capital: "Atlanta",
      imgURL: "georgia.png",
      population:75000
    },
    {
      state: "hawaii",
      capital: "Honolulu",
      imgURL: "hawaii.png",
      population:907897
    },
    {
      state: "idaho",
      capital: "Boise",
      imgURL: "idaho.png",
      population:7678678
    },
    {
      state: "illinois",
      capital: "Springfield",
      imgURL: "illinois.png",
      population:3453854
    },
    {
      state: "indiana",
      capital: "Indianapolis",
      imgURL: "indiana.png",
      population:345345
    },
    {
      state: "iowa",
      capital: "Des Moines",
      imgURL: "iowa.png",
      population:3453854
    },
    {
      state: "kansas",
      capital: "Topeka",
      imgURL: "kansas.png",
      population:456678
    },
    {
      state: "kentucky",
      capital: "Frankfort",
      imgURL: "kentucky.png",
      population:123000
    },
    {
      state: "louisiana",
      capital: "Baton Rouge",
      imgURL: "louisiana.png",
      population:3345443
    },
    {
      state: "maine",
      capital: "Augusta",
      imgURL: "maine.png",
      population:9770554
    },
    {
      state: "maryland",
      capital: "Annapolis",
      imgURL: "maryland.png",
      population:34534345
    },
    {
      state: "massachusetts",
      capital: "Boston",
      imgURL: "massachusetts.png",
      population:90000
    },
    {
      state: "michigan",
      capital: "Lansing",
      imgURL: "michigan.png",
      population:3453854
    },
    {
      state: "minnesota",
      capital: "St. Paul",
      imgURL: "minnesota.png",
      population:1234567
    },
    {
      state: "mississippi",
      capital: "Jackson",
      imgURL: "mississippi.png",
      population:500000
    },
    {
      state: "missouri",
      capital: "Jefferson City",
      imgURL: "missouri.png",
      population:1234567
    },
    {
      state: "montana",
      capital: "Helena",
      imgURL: "montana.png",
      population:3453854
    },
    {
      state: "nebraska",
      capital: "Lincoln",
      imgURL: "nebraska.png",
      population:3453854
    },
    {
      state: "nevada",
      capital: "Carson City",
      imgURL: "nevada.png",
      population:3453867
    },
    {
      state: "new hampshire",
      capital: "Concord",
      imgURL: "new_hampshire.png",
      population:3453324
    },
    {
      state: "new jersey",
      capital: "Trenton",
      imgURL: "new_jersey.png",
      population:3453776
    },
    {
      state: "new mexico",
      capital: "Santa Fe",
      imgURL: "new_mexico.png",
      population:3453332
    },
    {
      state: "new york",
      capital: "Albany",
      imgURL: "new_york.png",
      population:8765433
    },
    {
      state: "north carolina",
      capital: "Raleigh",
      imgURL: "north_carolina.png",
      population:2345678
    },
    {
      state: "north dakota",
      capital: "Bismarck",
      imgURL: "north_dakota.png",
      population:3453342
    },
    {
      state: "ohio",
      capital: "Columbus",
      imgURL: "ohio.png",
      population:34587878
    },
    {
      state: "oklahoma",
      capital: "Oklahoma City",
      imgURL: "oklahoma.png",
      population:34538234
    },
    {
      state: "oregon",
      capital: "Salem",
      imgURL: "oregon.png",
      population:90000
    },
    {
      state: "pennsylvania",
      capital: "Harrisburg",
      imgURL: "pennsylvania.png",
      population:3453854
    },
    {
      state: "rhode island",
      capital: "Providence",
      imgURL: "rhode_island.png",
      population:90000
    },
    {
      state: "south carolina",
      capital: "Columbia",
      imgURL: "south_carolina.png",
      population:90000
    },
    {
      state: "south dakota",
      capital: "Pierre",
      imgURL: "south_dakota.png",
      population:90000
    },
    {
      state: "tennessee",
      capital: "Nashville",
      imgURL: "tennessee.png",
      population:123000
    },
    {
      state: "texas",
      capital: "Austin",
      imgURL: "texas.png",
      population:90000
    },
    {
      state: "utah",
      capital: "Salt Lake City",
      imgURL: "utah.png",
      population:45000
    },
    {
      state: "vermont",
      capital: "Montpelier",
      imgURL: "vermont.png",
      population:90000
    },
    {
      state: "virginia",
      capital: "Richmond",
      imgURL: "virginia.png",
      population:345667
    },
    {
      state: "washington",
      capital: "Olympia",
      imgURL: "washington.png",
      population:345667
    },
    {
      state: "west virginia",
      capital: "Charleston",
      imgURL: "west_virginia.png",
      population:345667
    },
    {
      state: "wisconsin",
      capital: "Madison",
      imgURL: "wisconsin.png",
      population:345667
    },
    {
      state: "wyoming",
      capital: "Cheyenne",
      imgURL: "wyoming.png",
      population:345667
    },
  ]
}
