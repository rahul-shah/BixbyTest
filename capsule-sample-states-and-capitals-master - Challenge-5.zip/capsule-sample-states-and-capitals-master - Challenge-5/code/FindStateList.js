const DATA = require("./Data");
const STATES_DATA = DATA.STATES_DATA
var console = require('console')

module.exports.function = function findStateList (populationfilter) {

  var stateList = new Array();
  

  for(var i=0;i<STATES_DATA.length;i++) {
    if(STATES_DATA[i].population >= populationfilter)
    {
      var tempObj = new Object();
      tempObj.state = STATES_DATA[i].state;
      tempObj.stateGraphic = STATES_DATA[i].imgURL;
      tempObj.population = STATES_DATA[i].population;
      stateList.push(tempObj)
    }
  }
  console.log(stateList)

  return stateList;
}