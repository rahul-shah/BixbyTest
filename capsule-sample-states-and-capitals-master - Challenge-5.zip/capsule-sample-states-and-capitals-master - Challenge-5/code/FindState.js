const DATA = require("./Data");
const STATES_DATA = DATA.STATES_DATA

module.exports.function = function findState (capitalInput) {
   
  let capitalLower = capitalInput.toLowerCase();
  let stateData =  STATES_DATA.find(word => word.capital.toLowerCase() === capitalLower);

  let state, stateGraphic,population;
  if (stateData) {
    state = stateData.state;
    stateGraphic = stateData.imgURL;
    population = stateData.population;
  }
 
  return {
    state: state,
    stateGraphic: stateGraphic,
    population: population
  } 
}
